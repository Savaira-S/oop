PERSONAL FINANCE TRACKER - LAYERED C# VERSION

Files:
- Program.cs: Presentation layer (console menus, user input/output)
- Services/FinanceService.cs: Business logic layer (transaction operations and calculations)
- DataAccess/FileManager.cs: Data access layer (loads/saves text files)
- Models/User.cs: User data model
- Models/Transaction.cs: Transaction data model

How to use:
1. Create a C# Console App project.
2. Add these folders and files, or copy the provided files into the project.
3. Ensure the project's default namespace does not conflict with PersonalFinanceTracker_Layered.
4. Run the program.

Demo login:
- User1 / pss14
- User2 / ibo12

Notes:
- Text files (User1.txt and User2.txt) are created in the application's working directory.
- This is a beginner-friendly learning example, not a production security design.
- Amounts use float to stay close to the original coursework.
