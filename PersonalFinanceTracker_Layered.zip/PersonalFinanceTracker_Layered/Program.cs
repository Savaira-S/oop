using System;
using PersonalFinanceTracker_Layered.DataAccess;
using PersonalFinanceTracker_Layered.Models;
using PersonalFinanceTracker_Layered.Services;

namespace PersonalFinanceTracker_Layered
{
    class Program
    {
        static void Main()
        {
            FinanceService service = new FinanceService(new FileManager());

            User[] users = new User[2];
            users[0] = new User("User1", "pss14");
            users[1] = new User("User2", "ibo12");

            service.LoadUser(users[0]);
            service.LoadUser(users[1]);

            while (true)
            {
                Console.Clear();
                Console.WriteLine("=== PERSONAL FINANCE TRACKER ===");
                Console.WriteLine("1. Login as User1");
                Console.WriteLine("2. Login as User2");
                Console.WriteLine("3. Exit");
                int loginChoice = ReadInt("Select option: ");

                if (loginChoice == 3)
                {
                    service.SaveUser(users[0]);
                    service.SaveUser(users[1]);
                    return;
                }

                if (loginChoice < 1 || loginChoice > 2)
                {
                    Pause("Invalid choice.");
                    continue;
                }

                User current = users[loginChoice - 1];
                string password = ReadText("Enter password for " + current.Name + ": ");

                if (password != current.Password)
                {
                    Pause("Incorrect password!");
                    continue;
                }

                bool loggedIn = true;

                while (loggedIn)
                {
                    Console.Clear();
                    Console.WriteLine("=== PERSONAL FINANCE TRACKER ===");
                    Console.WriteLine("Logged in as: " + current.Name);
                    Console.WriteLine("1. Add transaction");
                    Console.WriteLine("2. View transactions");
                    Console.WriteLine("3. Calculate balance");
                    Console.WriteLine("4. Set initial budget");
                    Console.WriteLine("5. Update transaction");
                    Console.WriteLine("6. Delete transaction");
                    Console.WriteLine("7. View total income");
                    Console.WriteLine("8. View total expenses");
                    Console.WriteLine("9. Clear all transactions");
                    Console.WriteLine("10. Change user (sign out)");
                    Console.WriteLine("11. Reset budget");
                    int choice = ReadInt("Enter choice: ");

                    if (choice == 1)
                    {
                        string date = ReadText("Enter date (DD/MM/YYYY): ");
                        string category = ReadText("Enter category: ");
                        float amount = ReadFloat("Enter amount: ");
                        bool expense = ReadInt("Type (1 expense, 0 income): ") == 1;

                        bool added = service.AddTransaction(current, date, category, amount, expense);
                        Pause(added ? "Transaction added!" : "Transaction limit reached!");
                    }
                    else if (choice == 2)
                    {
                        if (current.Count == 0)
                            Console.WriteLine("No transactions available.");
                        else
                        {
                            Console.WriteLine("Index\\tDate\\t\\tCategory\\tAmount\\tType");
                            for (int i = 0; i < current.Count; i++)
                            {
                                Transaction t = current.Transactions[i];
                                Console.WriteLine(i + "\\t" + t.Date + "\\t" + t.Category + "\\t" +
                                                  t.Amount + "\\t" + (t.IsExpense ? "Expense" : "Income"));
                            }
                        }
                        Pause();
                    }
                    else if (choice == 3)
                    {
                        Console.WriteLine("Initial budget: " + current.Budget);
                        Console.WriteLine("Total income: " + service.GetTotalIncome(current));
                        Console.WriteLine("Total expenses: " + service.GetTotalExpenses(current));
                        Console.WriteLine("Remaining balance: " + service.GetRemainingBalance(current));
                        if (service.GetRemainingBalance(current) < 0)
                            Console.WriteLine("Warning: You are over budget!");
                        Pause();
                    }
                    else if (choice == 4)
                    {
                        current.Budget = ReadFloat("Enter initial budget: ");
                        Pause("Budget updated!");
                    }
                    else if (choice == 5)
                    {
                        int index = ReadInt("Enter transaction index to update: ");
                        string date = ReadText("Enter new date: ");
                        string category = ReadText("Enter new category: ");
                        float amount = ReadFloat("Enter new amount: ");
                        bool expense = ReadInt("Type (1 expense, 0 income): ") == 1;
                        Pause(service.UpdateTransaction(current, index, date, category, amount, expense)
                            ? "Transaction updated!" : "Invalid index!");
                    }
                    else if (choice == 6)
                    {
                        int index = ReadInt("Enter transaction index to delete: ");
                        Pause(service.DeleteTransaction(current, index)
                            ? "Transaction deleted!" : "Invalid index!");
                    }
                    else if (choice == 7)
                    {
                        Console.WriteLine("Total income: " + service.GetTotalIncome(current));
                        Pause();
                    }
                    else if (choice == 8)
                    {
                        Console.WriteLine("Total expenses: " + service.GetTotalExpenses(current));
                        Pause();
                    }
                    else if (choice == 9)
                    {
                        int confirm = ReadInt("Delete ALL transactions? (1 yes, 0 no): ");
                        if (confirm == 1)
                        {
                            service.ClearTransactions(current);
                            Pause("All transactions cleared.");
                        }
                        else
                            Pause("Operation cancelled.");
                    }
                    else if (choice == 10)
                    {
                        service.SaveUser(current);
                        loggedIn = false;
                    }
                    else if (choice == 11)
                    {
                        current.Budget = 0;
                        Pause("Budget reset to zero.");
                    }
                    else
                    {
                        Pause("Invalid choice.");
                    }
                }
            }
        }

        static string ReadText(string prompt)
        {
            Console.Write(prompt);
            return Console.ReadLine() ?? "";
        }

        static int ReadInt(string prompt)
        {
            int value;
            while (true)
            {
                Console.Write(prompt);
                if (int.TryParse(Console.ReadLine(), out value))
                    return value;
                Console.WriteLine("Please enter a whole number.");
            }
        }

        static float ReadFloat(string prompt)
        {
            float value;
            while (true)
            {
                Console.Write(prompt);
                if (float.TryParse(Console.ReadLine(), out value))
                    return value;
                Console.WriteLine("Please enter a valid amount.");
            }
        }

        static void Pause(string message = "")
        {
            if (message != "")
                Console.WriteLine(message);
            Console.WriteLine("Press Enter to continue...");
            Console.ReadLine();
        }
    }
}
